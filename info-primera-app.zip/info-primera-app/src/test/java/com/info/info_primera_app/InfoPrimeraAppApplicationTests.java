package com.info.info_primera_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoPrimeraAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
