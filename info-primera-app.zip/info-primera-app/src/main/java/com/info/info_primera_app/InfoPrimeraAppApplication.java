package com.info.info_primera_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoPrimeraAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoPrimeraAppApplication.class, args);
	}

}
